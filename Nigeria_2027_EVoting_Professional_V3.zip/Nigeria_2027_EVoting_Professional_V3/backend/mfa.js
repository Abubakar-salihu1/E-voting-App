import { authenticator } from 'otplib';

export function generateSecret() {
  return authenticator.generateSecret();
}

export function otpauthUrl(email, secret) {
  return authenticator.keyuri(email, 'NaijaVote', secret);
}

export function verifyTotp(token, secret) {
  try {
    return authenticator.verify({ token: String(token || ''), secret });
  } catch {
    return false;
  }
}
