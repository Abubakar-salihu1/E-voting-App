import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { v4 as uuid } from 'uuid';
import rateLimit from 'express-rate-limit';

import { db } from './db.js';
import { log } from './audit.js';
import { validatePassword, nowIso, addHours, isPast } from './utils.js';
import {
  authenticate, authorize, issueSession, revokeSession, revokeAllSessionsForUser,
  issueStepUpToken, requireStepUp
} from './auth-middleware.js';
import {
  ZONES, STATES, MFA_MANDATORY_ROLES, canAppoint, jurisdictionOk, visibleRoleSet, withinJurisdiction
} from './rbac.js';
import { generateSecret, otpauthUrl, verifyTotp } from './mfa.js';

const app = express();
const PORT = process.env.PORT || 4000;

app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_ORIGIN || true, credentials: true }));
app.use(express.json({ limit: '100kb' }));
app.use(morgan('dev'));

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Too many attempts. Please wait before trying again.' }
});

// ---------- helpers ----------

const publicUser = (u) => ({
  id: u.id, email: u.email, role: u.role, zone: u.zone, state: u.state, lga: u.lga,
  verified: !!u.verified, hasVoted: !!u.has_voted, mfaEnabled: !!u.mfa_enabled, status: u.status
});

function findUserByEmail(email) {
  return db.prepare('SELECT * FROM users WHERE email = ?').get(String(email || '').toLowerCase());
}

function hashToken(raw) {
  return crypto.createHash('sha256').update(raw).digest('hex');
}

function isLocked(user) {
  return user.locked_until && !isPast(user.locked_until);
}

function registerFailedAttempt(user) {
  const attempts = (user.failed_attempts || 0) + 1;
  const lockUntil = attempts >= 5 ? addHours(0.25) : null; // 15 minute lock after 5 misses
  db.prepare('UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?')
    .run(attempts, lockUntil, user.id);
}

function clearFailedAttempts(userId) {
  db.prepare('UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?').run(userId);
}

function issuePreAuthToken(userId, purpose) {
  const id = uuid();
  db.prepare(
    'INSERT INTO pre_auth_tokens (id, user_id, purpose, expires_at, used) VALUES (?,?,?,?,0)'
  ).run(id, userId, purpose, addHours(0.166)); // 10 minutes
  return id;
}

function consumePreAuthToken(id, purpose) {
  const row = db.prepare('SELECT * FROM pre_auth_tokens WHERE id = ?').get(id);
  if (!row || row.used === 1 || row.purpose !== purpose || isPast(row.expires_at)) return null;
  db.prepare('UPDATE pre_auth_tokens SET used = 1 WHERE id = ?').run(id);
  return row;
}

// ---------- health & reference data ----------

app.get('/api/health', (req, res) => res.json({ status: 'ok', concept: true }));
app.get('/api/reference/jurisdictions', (req, res) => res.json({ zones: ZONES, states: STATES }));

// ---------- voter self-registration ----------

app.post('/api/auth/signup', authLimiter, async (req, res) => {
  const { email, password, nin, voterCard } = req.body || {};
  if (!email || !password || !nin || !voterCard) {
    return res.status(400).json({ message: 'Email, password, NIN and voter card are all required.' });
  }
  const pwError = validatePassword(password);
  if (pwError) return res.status(400).json({ message: pwError });
  if (findUserByEmail(email)) return res.status(409).json({ message: 'An account already exists for this email.' });

  const user = {
    id: uuid(),
    email: String(email).toLowerCase(),
    password_hash: await bcrypt.hash(password, 12),
    role: 'VOTER',
    nin_hash: hashToken(String(nin)),
    voter_card_hash: hashToken(String(voterCard)),
    status: 'ACTIVE',
    created_at: nowIso()
  };
  db.prepare(
    `INSERT INTO users (id, email, password_hash, role, nin_hash, voter_card_hash, status, verified, has_voted, created_at)
     VALUES (@id, @email, @password_hash, @role, @nin_hash, @voter_card_hash, @status, 0, 0, @created_at)`
  ).run(user);
  log('Voter account created', user.email);
  const { token } = issueSession(user);
  res.json({ token, user: publicUser({ ...user, verified: 0, has_voted: 0, mfa_enabled: 0 }) });
});

// ---------- login (credentials -> optional MFA step -> session) ----------

app.post('/api/auth/login', authLimiter, async (req, res) => {
  const { email, password } = req.body || {};
  const user = findUserByEmail(email);

  // Same generic message whether the account doesn't exist or the password
  // is wrong, so a caller can't use this endpoint to enumerate accounts.
  const invalid = () => res.status(401).json({ message: 'Invalid credentials.' });

  if (!user || user.status !== 'ACTIVE' || !user.password_hash) return invalid();
  if (isLocked(user)) {
    return res.status(423).json({ message: 'Account temporarily locked after repeated failed attempts. Try again later.' });
  }

  const ok = await bcrypt.compare(password || '', user.password_hash);
  if (!ok) {
    registerFailedAttempt(user);
    log('Failed login attempt', user.email, 'FAILURE');
    return invalid();
  }
  clearFailedAttempts(user.id);

  const mfaRequiredForRole = MFA_MANDATORY_ROLES.includes(user.role);
  if (mfaRequiredForRole && !user.mfa_enabled) {
    // Sensitive roles cannot get a session until MFA is actually turned on.
    const preAuthToken = issuePreAuthToken(user.id, 'mfa_setup');
    return res.json({ mfaSetupRequired: true, preAuthToken });
  }
  if (user.mfa_enabled) {
    const preAuthToken = issuePreAuthToken(user.id, 'mfa_login');
    return res.json({ mfaRequired: true, preAuthToken });
  }

  log('Login', user.email);
  const { token } = issueSession(user);
  res.json({ token, user: publicUser(user) });
});

app.post('/api/auth/mfa/verify', authLimiter, (req, res) => {
  const { preAuthToken, code } = req.body || {};
  const row = consumePreAuthToken(preAuthToken, 'mfa_login');
  if (!row) return res.status(401).json({ message: 'This verification step has expired. Please log in again.' });
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(row.user_id);
  if (!user || !verifyTotp(code, user.mfa_secret)) {
    log('Failed MFA verification', user?.email || row.user_id, 'FAILURE');
    return res.status(401).json({ message: 'Incorrect authentication code.' });
  }
  log('Login (MFA verified)', user.email);
  const { token } = issueSession(user);
  res.json({ token, user: publicUser(user) });
});

app.post('/api/auth/logout', authenticate, (req, res) => {
  revokeSession(req.sessionId);
  log('Logout', req.user.email);
  res.json({ message: 'Logged out.' });
});

// ---------- MFA setup (any authenticated account can turn it on) ----------

app.post('/api/auth/mfa/setup', authenticate, (req, res) => {
  const secret = generateSecret();
  db.prepare('UPDATE users SET mfa_pending_secret = ? WHERE id = ?').run(secret, req.user.id);
  res.json({ secret, otpauthUrl: otpauthUrl(req.user.email, secret) });
});

app.post('/api/auth/mfa/confirm', authenticate, (req, res) => {
  const { code } = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (!user.mfa_pending_secret || !verifyTotp(code, user.mfa_pending_secret)) {
    return res.status(400).json({ message: 'Incorrect code. Scan the QR code again and retry.' });
  }
  db.prepare('UPDATE users SET mfa_enabled = 1, mfa_secret = ?, mfa_pending_secret = NULL WHERE id = ?')
    .run(user.mfa_pending_secret, user.id);
  log('MFA enabled', user.email);
  res.json({ message: 'Multi-factor authentication is now active on this account.' });
});

// A sensitive-role account that logged in without MFA enabled gets a
// preAuthToken instead of a session — this lets it complete setup once,
// then it must verify a code before a real session is issued going forward.
app.post('/api/auth/mfa/setup-with-preauth', authLimiter, (req, res) => {
  const { preAuthToken } = req.body || {};
  const row = consumePreAuthToken(preAuthToken, 'mfa_setup');
  if (!row) return res.status(401).json({ message: 'This step has expired. Please log in again.' });
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(row.user_id);
  const secret = generateSecret();
  db.prepare('UPDATE users SET mfa_pending_secret = ? WHERE id = ?').run(secret, user.id);
  const newPreAuth = issuePreAuthToken(user.id, 'mfa_setup_confirm');
  res.json({ secret, otpauthUrl: otpauthUrl(user.email, secret), preAuthToken: newPreAuth });
});

app.post('/api/auth/mfa/confirm-with-preauth', authLimiter, (req, res) => {
  const { preAuthToken, code } = req.body || {};
  const row = consumePreAuthToken(preAuthToken, 'mfa_setup_confirm');
  if (!row) return res.status(401).json({ message: 'This step has expired. Please log in again.' });
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(row.user_id);
  if (!user.mfa_pending_secret || !verifyTotp(code, user.mfa_pending_secret)) {
    return res.status(400).json({ message: 'Incorrect code.' });
  }
  db.prepare('UPDATE users SET mfa_enabled = 1, mfa_secret = ?, mfa_pending_secret = NULL WHERE id = ?')
    .run(user.mfa_pending_secret, user.id);
  log('MFA enabled (mandatory for role)', user.email);
  const { token } = issueSession(user);
  res.json({ token, user: publicUser(user) });
});

// ---------- official activation (replaces hard-coded demo credentials) ----------
// New officials are created by an admin above them with NO password —
// only a one-time activation token, which the appointing admin delivers to
// them out of band. The account cannot log in until this runs.

app.post('/api/auth/activate', authLimiter, async (req, res) => {
  const { token, password } = req.body || {};
  if (!token || !password) return res.status(400).json({ message: 'Activation token and a new password are required.' });
  const pwError = validatePassword(password);
  if (pwError) return res.status(400).json({ message: pwError });

  const tokenHash = hashToken(token);
  const user = db.prepare(
    'SELECT * FROM users WHERE provisioning_token_hash = ? AND status = ?'
  ).get(tokenHash, 'PENDING_ACTIVATION');

  if (!user || isPast(user.provisioning_expires_at)) {
    return res.status(400).json({ message: 'This activation link is invalid or has expired. Ask your appointing officer to reissue it.' });
  }

  db.prepare(
    `UPDATE users SET password_hash = ?, status = 'ACTIVE', provisioning_token_hash = NULL,
     provisioning_expires_at = NULL WHERE id = ?`
  ).run(await bcrypt.hash(password, 12), user.id);
  log('Official account activated', user.email);
  res.json({ message: 'Account activated. You can now log in.' });
});

// ---------- step-up verification for sensitive administrative actions ----------
// Being logged in is not enough to appoint or revoke an official, or to
// publish a candidate: those actions also require a step-up token, minted
// here from a fresh MFA code and valid for 5 minutes.

app.post('/api/auth/step-up', authenticate, authLimiter, (req, res) => {
  const { code } = req.body || {};
  if (!req.user.mfa_enabled) {
    return res.status(400).json({ message: 'Multi-factor authentication must be enabled on this account before it can confirm sensitive actions.' });
  }
  if (!verifyTotp(code, req.user.mfa_secret)) {
    log('Failed step-up verification', req.user.email, 'FAILURE');
    return res.status(401).json({ message: 'Incorrect authentication code.' });
  }
  const { id, expiresAt } = issueStepUpToken(req.sessionId, req.user.id);
  log('Step-up verification for a sensitive action', req.user.email);
  res.json({ stepUpToken: id, expiresAt });
});

// ---------- identity verification (voter demo step, unchanged in spirit) ----------

app.post('/api/verification/demo', authenticate, (req, res) => {
  db.prepare('UPDATE users SET verified = 1 WHERE id = ?').run(req.user.id);
  const type = req.body?.type || 'identity';
  log(`Demo ${type} verification`, req.user.email);
  res.json({ message: `Demo ${type} verification completed.` });
});

// ---------- elections & candidates ----------

app.get('/api/elections/candidates', authenticate, (req, res) => {
  const level = req.query.level || 'Federal';
  const rows = db.prepare('SELECT * FROM candidates WHERE level = ?').all(level);
  res.json({
    level,
    candidates: rows.map(c => ({ id: c.id, name: c.name, party: c.party, image: c.image }))
  });
});

const federalAdmins = authorize('SUPER_ADMIN', 'INEC_CHAIRMAN');
app.post('/api/candidates', authenticate, federalAdmins, requireStepUp, (req, res) => {
  const { name, party, level, image } = req.body || {};
  if (!name || !party || !level) return res.status(400).json({ message: 'Name, party and level are required.' });
  const candidate = {
    id: uuid(), name, party, level,
    image: image || 'https://placehold.co/160x160?text=' + encodeURIComponent(name[0] || '?'),
    created_at: nowIso()
  };
  db.prepare(
    'INSERT INTO candidates (id, name, party, level, image, created_at) VALUES (@id, @name, @party, @level, @image, @created_at)'
  ).run(candidate);
  log(`Candidate added: ${name} (${party}, ${level})`, req.user.email);
  res.json({ candidate });
});

// ---------- ballots ----------

const GENESIS_HASH = '0'.repeat(64);
const PUBLIC_TALLY_THRESHOLD = Number(process.env.PUBLIC_TALLY_THRESHOLD || 5);

function ledgerReceipt({ id, candidateId, electionLevel, contest, createdAt }) {
  const last = db.prepare('SELECT receipt_hash FROM votes ORDER BY seq DESC LIMIT 1').get();
  const prevHash = last ? last.receipt_hash : GENESIS_HASH;
  const receiptHash = crypto.createHash('sha256')
    .update(`${id}|${candidateId}|${electionLevel}|${contest}|${createdAt}|${prevHash}`)
    .digest('hex');
  return { prevHash, receiptHash };
}

app.post('/api/votes', authenticate, (req, res) => {
  if (req.user.role !== 'VOTER') return res.status(403).json({ message: 'Only voter accounts can cast a ballot.' });
  if (!req.user.verified) return res.status(403).json({ message: 'Complete verification first.' });
  if (req.user.has_voted) return res.status(409).json({ message: 'This voter has already submitted a ballot.' });

  const { electionLevel, contest, candidateId } = req.body || {};
  if (!electionLevel || !contest || !candidateId) return res.status(400).json({ message: 'Incomplete ballot.' });
  const candidate = db.prepare('SELECT * FROM candidates WHERE id = ?').get(candidateId);
  if (!candidate) return res.status(400).json({ message: 'Unknown candidate.' });

  db.prepare('UPDATE users SET has_voted = 1 WHERE id = ?').run(req.user.id);
  const id = uuid();
  const createdAt = nowIso();
  const confirmation = 'DEMO-' + id.slice(0, 8).toUpperCase();
  const { prevHash, receiptHash } = ledgerReceipt({ id, candidateId, electionLevel, contest, createdAt });

  // No column here ever references who cast this ballot — the row is the
  // whole record. Anonymity comes from that absence, not from hiding the
  // row itself; the row (minus any voter link) is exactly what's published
  // to the public ledger below.
  const seq = db.prepare('SELECT COUNT(*) AS n FROM votes').get().n + 1;
  db.prepare(
    `INSERT INTO votes (id, seq, election_level, contest, candidate_id, confirmation, prev_hash, receipt_hash, created_at)
     VALUES (?,?,?,?,?,?,?,?,?)`
  ).run(id, seq, electionLevel, contest, candidateId, confirmation, prevHash, receiptHash, createdAt);
  log('Ballot submitted', req.user.email);
  res.json({ confirmation, receiptHash, ledgerIndex: seq });
});

// ---------- public, no-login transparency: tally + verifiable ledger ----------
// Nothing below this line requires authentication. Anyone who downloads
// the app — press, party agents, international observers, an ordinary
// citizen — can see live totals and independently verify the ledger
// hasn't been tampered with, without ever needing an account.

app.get('/api/public/ledger', (req, res) => {
  const rows = db.prepare(
    `SELECT v.*, c.name AS candidate_name, c.party AS candidate_party
     FROM votes v LEFT JOIN candidates c ON c.id = v.candidate_id
     ORDER BY v.seq ASC`
  ).all();
  res.json({
    genesisHash: GENESIS_HASH,
    entries: rows.map(r => ({
      id: r.id,
      index: r.seq,
      level: r.election_level,
      contest: r.contest,
      candidateId: r.candidate_id,
      candidateLabel: r.candidate_name ? `${r.candidate_name} (${r.candidate_party})` : r.candidate_id,
      time: r.created_at,
      prevHash: r.prev_hash,
      receiptHash: r.receipt_hash
    }))
  });
});

app.get('/api/public/tally', (req, res) => {
  const level = req.query.level || 'Federal';
  const total = db.prepare('SELECT COUNT(*) AS n FROM votes WHERE election_level = ?').get(level).n;
  if (total < PUBLIC_TALLY_THRESHOLD) {
    return res.json({ level, revealed: false, totalVotes: total, threshold: PUBLIC_TALLY_THRESHOLD });
  }
  const rows = db.prepare(
    `SELECT c.id, c.name, c.party, COUNT(v.id) AS votes
     FROM candidates c LEFT JOIN votes v ON v.candidate_id = c.id AND v.election_level = ?
     WHERE c.level = ? GROUP BY c.id`
  ).all(level, level);
  res.json({ level, revealed: true, totalVotes: total, results: rows });
});

app.get('/api/public/stats', (req, res) => {
  const demoVoteCount = db.prepare('SELECT COUNT(*) AS n FROM votes').get().n;
  res.json({ demoVoteCount, elections: ['Federal', 'State', 'Local Government'], tallyThreshold: PUBLIC_TALLY_THRESHOLD });
});

// ---------- officials registry (federal / state / local hierarchy) ----------

const adminRoles = authorize('SUPER_ADMIN', 'INEC_CHAIRMAN', 'ZONAL_COMMISSIONER', 'STATE_ELECTORAL_OFFICER');

app.post('/api/officials', authenticate, adminRoles, requireStepUp, (req, res) => {
  const { name, email, role, zone, state, lga } = req.body || {};
  if (!name || !email || !role) return res.status(400).json({ message: 'Name, email and role are required.' });
  if (!canAppoint(req.user.role, role)) {
    return res.status(403).json({ message: `Your role cannot appoint a ${role.replaceAll('_', ' ').toLowerCase()}.` });
  }
  if (!jurisdictionOk(req.user, { role, zone, state, lga })) {
    return res.status(403).json({ message: 'That jurisdiction is outside your own zone or state.' });
  }
  if (findUserByEmail(email)) return res.status(409).json({ message: 'An account already exists for this email.' });

  const rawToken = crypto.randomBytes(24).toString('hex');
  const user = {
    id: uuid(),
    email: String(email).toLowerCase(),
    role,
    zone: role === 'ZONAL_COMMISSIONER' ? zone : null,
    state: (role === 'STATE_ELECTORAL_OFFICER' || role === 'LGA_ELECTORAL_OFFICER') ? state : null,
    lga: role === 'LGA_ELECTORAL_OFFICER' ? lga : null,
    status: 'PENDING_ACTIVATION',
    created_by: req.user.email,
    created_at: nowIso(),
    provisioning_token_hash: hashToken(rawToken),
    provisioning_expires_at: addHours(24)
  };
  db.prepare(
    `INSERT INTO users (id, email, role, zone, state, lga, status, created_by, created_at, provisioning_token_hash, provisioning_expires_at, verified, has_voted)
     VALUES (@id, @email, @role, @zone, @state, @lga, @status, @created_by, @created_at, @provisioning_token_hash, @provisioning_expires_at, 1, 0)`
  ).run(user);
  log(`Official appointed: ${role} (${email})`, req.user.email);

  // The raw activation token is returned once, here, for the appointing
  // officer to deliver to the appointee out of band (never emailed or
  // logged in plain text). It cannot be retrieved again after this response.
  res.json({
    official: publicUser({ ...user, mfa_enabled: 0 }),
    activationToken: rawToken,
    activationExpiresAt: user.provisioning_expires_at
  });
});

const viewOfficialsRoles = authorize('SUPER_ADMIN', 'INEC_CHAIRMAN', 'ZONAL_COMMISSIONER', 'STATE_ELECTORAL_OFFICER', 'SECURITY_AUDIT_OFFICER');
app.get('/api/officials', authenticate, viewOfficialsRoles, (req, res) => {
  const roleSet = visibleRoleSet(req.user.role);
  if (roleSet.length === 0) return res.json({ officials: [] });
  const placeholders = roleSet.map(() => '?').join(',');
  const rows = db.prepare(`SELECT * FROM users WHERE role IN (${placeholders})`).all(...roleSet);
  const scoped = withinJurisdiction(req.user, rows);
  res.json({ officials: scoped.map(publicUser) });
});

app.post('/api/officials/:id/revoke', authenticate, adminRoles, requireStepUp, (req, res) => {
  const target = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!target) return res.status(404).json({ message: 'Official not found.' });
  if (!canAppoint(req.user.role, target.role) || !jurisdictionOk(req.user, target)) {
    return res.status(403).json({ message: 'You do not have authority over this account.' });
  }
  db.prepare("UPDATE users SET status = 'REVOKED', revoked_at = ?, revoked_by = ? WHERE id = ?")
    .run(nowIso(), req.user.email, target.id);
  revokeAllSessionsForUser(target.id); // kill any session they currently hold, immediately
  log(`Official access revoked: ${target.role} (${target.email})`, req.user.email);
  res.json({ message: 'Access revoked and all active sessions for this account were terminated.' });
});

// ---------- audit & transparency ----------

app.get('/api/audit', authenticate, authorize('SUPER_ADMIN', 'INEC_CHAIRMAN', 'SECURITY_AUDIT_OFFICER'), (req, res) => {
  const rows = db.prepare('SELECT * FROM audit_log ORDER BY time DESC LIMIT 200').all();
  res.json({ events: rows });
});

app.listen(PORT, () => console.log(`NaijaVote API listening on http://localhost:${PORT}`));
