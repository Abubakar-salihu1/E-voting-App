// Nigeria's six geopolitical zones, and which of the 36 states + FCT sit in each.
// This is what lets a Zonal Commissioner's authority stay inside their own
// zone, and a State Electoral Officer's authority stay inside their own state.
export const ZONES = [
  'North Central',
  'North East',
  'North West',
  'South East',
  'South South',
  'South West'
];

export const STATE_ZONE_MAP = {
  'Benue': 'North Central', 'Kogi': 'North Central', 'Kwara': 'North Central',
  'Nasarawa': 'North Central', 'Niger': 'North Central', 'Plateau': 'North Central',
  'FCT': 'North Central',
  'Adamawa': 'North East', 'Bauchi': 'North East', 'Borno': 'North East',
  'Gombe': 'North East', 'Taraba': 'North East', 'Yobe': 'North East',
  'Jigawa': 'North West', 'Kaduna': 'North West', 'Kano': 'North West',
  'Katsina': 'North West', 'Kebbi': 'North West', 'Sokoto': 'North West', 'Zamfara': 'North West',
  'Abia': 'South East', 'Anambra': 'South East', 'Ebonyi': 'South East',
  'Enugu': 'South East', 'Imo': 'South East',
  'Akwa Ibom': 'South South', 'Bayelsa': 'South South', 'Cross River': 'South South',
  'Delta': 'South South', 'Edo': 'South South', 'Rivers': 'South South',
  'Ekiti': 'South West', 'Lagos': 'South West', 'Ogun': 'South West',
  'Ondo': 'South West', 'Osun': 'South West', 'Oyo': 'South West'
};

export const STATES = Object.keys(STATE_ZONE_MAP);

// Order matters here only as a readable top-to-bottom map of authority.
// SUPER_ADMIN: platform owner — provisions the INEC Chairman, nothing else.
// INEC_CHAIRMAN: elected/assigned by the Super Admin — national authority,
//   appoints the six Zonal Commissioners and federal-level election setup.
// ZONAL_COMMISSIONER: one of the six geopolitical zones — appoints State
//   Electoral Officers for states inside their own zone only.
// STATE_ELECTORAL_OFFICER: appoints LGA Electoral Officers inside their state.
// LGA_ELECTORAL_OFFICER: runs local-government-level election operations.
// SECURITY_AUDIT_OFFICER: cross-cutting, read-only — sees the audit trail
//   at every level but cannot appoint anyone or touch ballots.
// VOTER: casts a ballot, nothing more.
export const ROLES = [
  'SUPER_ADMIN',
  'INEC_CHAIRMAN',
  'ZONAL_COMMISSIONER',
  'STATE_ELECTORAL_OFFICER',
  'LGA_ELECTORAL_OFFICER',
  'SECURITY_AUDIT_OFFICER',
  'VOTER'
];

// Privileged accounts must not be reachable with a password alone: the
// platform owner, the national administrator, every regional/state-level
// senior official in the appointment chain, and the security/audit role.
// Only the most junior admin tier (LGA) and ordinary voters are exempt —
// MFA is still offered to them from Settings, just not forced at login.
export const MFA_MANDATORY_ROLES = [
  'SUPER_ADMIN',
  'INEC_CHAIRMAN',
  'ZONAL_COMMISSIONER',
  'STATE_ELECTORAL_OFFICER',
  'SECURITY_AUDIT_OFFICER'
];

const APPOINTMENT_RULES = {
  SUPER_ADMIN: ['INEC_CHAIRMAN', 'SECURITY_AUDIT_OFFICER'],
  INEC_CHAIRMAN: ['ZONAL_COMMISSIONER', 'SECURITY_AUDIT_OFFICER'],
  ZONAL_COMMISSIONER: ['STATE_ELECTORAL_OFFICER'],
  STATE_ELECTORAL_OFFICER: ['LGA_ELECTORAL_OFFICER']
};

export function canAppoint(actorRole, targetRole) {
  return (APPOINTMENT_RULES[actorRole] || []).includes(targetRole);
}

// Confirms the jurisdiction fields supplied for a new/target official are
// actually inside the appointing official's own remit.
export function jurisdictionOk(actor, target) {
  switch (actor.role) {
    case 'SUPER_ADMIN':
    case 'INEC_CHAIRMAN':
      return true; // national scope
    case 'ZONAL_COMMISSIONER':
      return target.role === 'STATE_ELECTORAL_OFFICER'
        && STATE_ZONE_MAP[target.state] === actor.zone;
    case 'STATE_ELECTORAL_OFFICER':
      return target.role === 'LGA_ELECTORAL_OFFICER'
        && target.state === actor.state;
    default:
      return false;
  }
}

// Which roles an actor is allowed to see in the officials registry.
export function visibleRoleSet(actorRole) {
  switch (actorRole) {
    case 'SUPER_ADMIN':
    case 'SECURITY_AUDIT_OFFICER':
      return ['INEC_CHAIRMAN', 'ZONAL_COMMISSIONER', 'STATE_ELECTORAL_OFFICER', 'LGA_ELECTORAL_OFFICER', 'SECURITY_AUDIT_OFFICER'];
    case 'INEC_CHAIRMAN':
      return ['ZONAL_COMMISSIONER', 'STATE_ELECTORAL_OFFICER', 'LGA_ELECTORAL_OFFICER'];
    case 'ZONAL_COMMISSIONER':
      return ['STATE_ELECTORAL_OFFICER', 'LGA_ELECTORAL_OFFICER'];
    case 'STATE_ELECTORAL_OFFICER':
      return ['LGA_ELECTORAL_OFFICER'];
    default:
      return [];
  }
}

// Narrows a list of official rows down to the ones inside the actor's own
// jurisdiction (national roles see everything the role filter allows).
export function withinJurisdiction(actor, rows) {
  if (actor.role === 'SUPER_ADMIN' || actor.role === 'SECURITY_AUDIT_OFFICER' || actor.role === 'INEC_CHAIRMAN') {
    return rows;
  }
  if (actor.role === 'ZONAL_COMMISSIONER') {
    return rows.filter(r => STATE_ZONE_MAP[r.state] === actor.zone);
  }
  if (actor.role === 'STATE_ELECTORAL_OFFICER') {
    return rows.filter(r => r.state === actor.state);
  }
  return [];
}
