import jwt from 'jsonwebtoken';
import { v4 as uuid } from 'uuid';
import { db } from './db.js';
import { nowIso, addHours, isPast } from './utils.js';

const SECRET = process.env.JWT_SECRET;
if (!SECRET || SECRET.length < 32) {
  throw new Error(
    'JWT_SECRET is missing or too short. Set a long random value in your .env file — see .env.example.'
  );
}
const TTL_HOURS = Number(process.env.SESSION_TTL_HOURS || 12);

// A session row in the database is what makes the session "protected":
// the JWT alone only proves who signed it, but every request also checks
// that the underlying session hasn't been revoked (logout, a password
// change, or an official losing their post all revoke it immediately).
export function issueSession(user) {
  const sessionId = uuid();
  db.prepare(
    'INSERT INTO sessions (id, user_id, created_at, expires_at, revoked) VALUES (?,?,?,?,0)'
  ).run(sessionId, user.id, nowIso(), addHours(TTL_HOURS));

  const token = jwt.sign(
    { sub: user.id, sid: sessionId, role: user.role },
    SECRET,
    { expiresIn: `${TTL_HOURS}h` }
  );
  return { token, expiresAt: addHours(TTL_HOURS) };
}

export function revokeSession(sessionId) {
  db.prepare('UPDATE sessions SET revoked = 1 WHERE id = ?').run(sessionId);
}

export function revokeAllSessionsForUser(userId) {
  db.prepare('UPDATE sessions SET revoked = 1 WHERE user_id = ?').run(userId);
}

const STEP_UP_TTL_HOURS = 5 / 60; // 5 minutes — deliberately short-lived

// A normal session proves "who is logged in"; a step-up token proves
// "this specific person just re-entered their MFA code, moments ago."
// Sensitive actions (appointing or revoking an official, publishing a
// candidate) require both — a stolen/left-open session alone isn't enough.
export function issueStepUpToken(sessionId, userId) {
  const id = uuid();
  const expiresAt = addHours(STEP_UP_TTL_HOURS);
  db.prepare(
    'INSERT INTO step_up_tokens (id, session_id, user_id, expires_at) VALUES (?,?,?,?)'
  ).run(id, sessionId, userId, expiresAt);
  return { id, expiresAt };
}

export function requireStepUp(req, res, next) {
  const token = req.headers['x-step-up-token'];
  if (!token) {
    return res.status(401).json({ stepUpRequired: true, message: 'This action requires a fresh authentication code.' });
  }
  const row = db.prepare(
    'SELECT * FROM step_up_tokens WHERE id = ? AND session_id = ? AND user_id = ?'
  ).get(token, req.sessionId, req.user.id);
  if (!row || isPast(row.expires_at)) {
    return res.status(401).json({ stepUpRequired: true, message: 'That confirmation has expired. Verify your code again to continue.' });
  }
  next();
}

export function authenticate(req, res, next) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authentication required.' });
  }
  let payload;
  try {
    payload = jwt.verify(header.slice(7), SECRET);
  } catch {
    return res.status(401).json({ message: 'Session expired or invalid.' });
  }

  const session = db.prepare('SELECT * FROM sessions WHERE id = ?').get(payload.sid);
  if (!session || session.revoked === 1 || isPast(session.expires_at)) {
    return res.status(401).json({ message: 'Session expired or invalid.' });
  }

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(payload.sub);
  if (!user || user.status !== 'ACTIVE') {
    return res.status(401).json({ message: 'This account no longer has active access.' });
  }

  req.user = user;
  req.sessionId = session.id;
  next();
}

export function authorize(...roles) {
  return (req, res, next) =>
    roles.includes(req.user.role)
      ? next()
      : res.status(403).json({ message: 'Your role does not permit this action.' });
}
