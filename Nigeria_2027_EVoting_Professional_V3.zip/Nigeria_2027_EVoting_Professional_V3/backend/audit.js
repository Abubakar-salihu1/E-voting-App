import { v4 as uuid } from 'uuid';
import { db } from './db.js';

// Administrative audit trail only — ballot choices are never written here.
// Rows are never deleted by application code, including when the actor's
// account is later revoked, so historical evidence survives a succession.
export function log(event, actor = 'SYSTEM', result = 'SUCCESS') {
  db.prepare(
    'INSERT INTO audit_log (id, time, event, actor, result) VALUES (?, ?, ?, ?, ?)'
  ).run(uuid(), new Date().toISOString(), event, actor, result);
}
