export function validatePassword(pw) {
  if (typeof pw !== 'string' || pw.length < 12) {
    return 'Password must be at least 12 characters long.';
  }
  if (!/[a-z]/.test(pw) || !/[A-Z]/.test(pw) || !/[0-9]/.test(pw)) {
    return 'Password must include an upper-case letter, a lower-case letter and a number.';
  }
  return null;
}

export function nowIso() {
  return new Date().toISOString();
}

export function addHours(hours) {
  return new Date(Date.now() + hours * 3600 * 1000).toISOString();
}

export function isPast(iso) {
  return !iso || new Date(iso).getTime() < Date.now();
}
