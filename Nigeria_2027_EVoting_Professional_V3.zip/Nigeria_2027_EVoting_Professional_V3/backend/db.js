import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { v4 as uuid } from 'uuid';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = process.env.DATA_DIR
  ? path.resolve(__dirname, process.env.DATA_DIR)
  : path.join(__dirname, 'data');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const DB_PATH = path.join(DATA_DIR, 'evoting.db');
export const db = new Database(DB_PATH);

// WAL mode gives durable writes with good concurrent-read performance —
// the data survives process restarts, crashes, and redeploys, unlike the
// previous in-memory Map() store which reset every time the server stopped.
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id                        TEXT PRIMARY KEY,
  email                     TEXT UNIQUE NOT NULL,
  password_hash             TEXT,
  role                      TEXT NOT NULL,
  zone                      TEXT,
  state                     TEXT,
  lga                       TEXT,
  status                    TEXT NOT NULL DEFAULT 'PENDING_ACTIVATION',
  verified                  INTEGER NOT NULL DEFAULT 0,
  has_voted                 INTEGER NOT NULL DEFAULT 0,
  mfa_enabled               INTEGER NOT NULL DEFAULT 0,
  mfa_secret                TEXT,
  mfa_pending_secret        TEXT,
  provisioning_token_hash   TEXT,
  provisioning_expires_at   TEXT,
  failed_attempts           INTEGER NOT NULL DEFAULT 0,
  locked_until              TEXT,
  created_by                TEXT,
  created_at                TEXT NOT NULL,
  revoked_at                TEXT,
  revoked_by                TEXT
);

CREATE TABLE IF NOT EXISTS sessions (
  id          TEXT PRIMARY KEY,
  user_id     TEXT NOT NULL REFERENCES users(id),
  created_at  TEXT NOT NULL,
  expires_at  TEXT NOT NULL,
  revoked     INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS pre_auth_tokens (
  id          TEXT PRIMARY KEY,
  user_id     TEXT NOT NULL REFERENCES users(id),
  purpose     TEXT NOT NULL,
  expires_at  TEXT NOT NULL,
  used        INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS step_up_tokens (
  id          TEXT PRIMARY KEY,
  session_id  TEXT NOT NULL REFERENCES sessions(id),
  user_id     TEXT NOT NULL REFERENCES users(id),
  expires_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS candidates (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  party       TEXT NOT NULL,
  level       TEXT NOT NULL,
  zone        TEXT,
  state       TEXT,
  lga         TEXT,
  image       TEXT,
  created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS votes (
  id              TEXT PRIMARY KEY,
  seq             INTEGER,
  election_level  TEXT NOT NULL,
  contest         TEXT NOT NULL,
  candidate_id    TEXT NOT NULL,
  confirmation    TEXT NOT NULL,
  prev_hash       TEXT NOT NULL,
  receipt_hash    TEXT NOT NULL,
  created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
  id      TEXT PRIMARY KEY,
  time    TEXT NOT NULL,
  event   TEXT NOT NULL,
  actor   TEXT NOT NULL,
  result  TEXT NOT NULL
);
`);

// Seed a small starting ballot so the ballot screen has something to show
// on a fresh database. Real deployments should replace this through the
// federal-level /api/candidates endpoint before an election opens.
const candidateCount = db.prepare('SELECT COUNT(*) AS n FROM candidates').get().n;
if (candidateCount === 0) {
  const insert = db.prepare(
    `INSERT INTO candidates (id, name, party, level, image, created_at) VALUES (?,?,?,?,?,?)`
  );
  const now = new Date().toISOString();
  insert.run(uuid(), 'Candidate A', 'Demo Party Alpha', 'Federal', 'https://placehold.co/160x160?text=A', now);
  insert.run(uuid(), 'Candidate B', 'Demo Party Beta', 'Federal', 'https://placehold.co/160x160?text=B', now);
  insert.run(uuid(), 'Candidate C', 'Demo Party Gamma', 'Federal', 'https://placehold.co/160x160?text=C', now);
}
