// Run once, by hand, on a trusted machine: `npm run bootstrap`
//
// This is the ONLY way a SUPER_ADMIN account is ever created. There is no
// default administrator baked into the application — this replaces that
// pattern with a deliberate, human-run provisioning step, per OWASP
// guidance on protecting the most sensitive accounts in a system.
//
// It reads credentials from environment variables if present (useful for
// scripted infrastructure setup where the values come from a secrets
// manager), and otherwise prompts for them interactively with the password
// hidden from the terminal. Either way, nothing is ever written to source
// code or checked into version control.

import bcrypt from 'bcryptjs';
import { v4 as uuid } from 'uuid';
import readline from 'readline';
import { db } from '../db.js';
import { validatePassword, nowIso } from '../utils.js';

function promptVisible(question) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(question, (answer) => { rl.close(); resolve(answer.trim()); });
  });
}

function promptHidden(question) {
  return new Promise((resolve) => {
    const stdin = process.stdin;
    process.stdout.write(question);
    stdin.resume();
    stdin.setRawMode(true);
    stdin.setEncoding('utf8');
    let input = '';
    const onData = (char) => {
      if (char === '\n' || char === '\r' || char === '\u0004') {
        stdin.setRawMode(false);
        stdin.pause();
        stdin.removeListener('data', onData);
        process.stdout.write('\n');
        resolve(input);
        return;
      }
      if (char === '\u0003') process.exit(1); // Ctrl+C
      if (char === '\u007f') { input = input.slice(0, -1); return; } // backspace
      input += char;
    };
    stdin.on('data', onData);
  });
}

async function main() {
  const existing = db.prepare("SELECT COUNT(*) AS n FROM users WHERE role = 'SUPER_ADMIN'").get().n;
  if (existing > 0) {
    console.error('A SUPER_ADMIN account already exists. Refusing to create another via this script.');
    console.error('Use the Officials screen (as an existing Super Admin) to manage administrator accounts instead.');
    process.exit(1);
  }

  let email = process.env.BOOTSTRAP_SUPER_ADMIN_EMAIL;
  let password = process.env.BOOTSTRAP_SUPER_ADMIN_PASSWORD;

  if (!email) email = await promptVisible('Super Admin email: ');
  if (!password) password = await promptHidden('Super Admin password (hidden): ');

  const pwError = validatePassword(password);
  if (pwError) {
    console.error('Rejected: ' + pwError);
    process.exit(1);
  }
  if (!email || !email.includes('@')) {
    console.error('Rejected: a valid email address is required.');
    process.exit(1);
  }

  const user = {
    id: uuid(),
    email: email.toLowerCase(),
    password_hash: await bcrypt.hash(password, 12),
    role: 'SUPER_ADMIN',
    status: 'ACTIVE',
    created_at: nowIso()
  };
  db.prepare(
    `INSERT INTO users (id, email, password_hash, role, status, verified, has_voted, created_at)
     VALUES (@id, @email, @password_hash, @role, @status, 1, 0, @created_at)`
  ).run(user);

  console.log('\nSuper Admin account created for ' + user.email + '.');
  console.log('This role requires multi-factor authentication: on first login you will');
  console.log('be walked through MFA setup before a session is issued. Nothing further');
  console.log('needs to be done here.\n');
  process.exit(0);
}

main();
