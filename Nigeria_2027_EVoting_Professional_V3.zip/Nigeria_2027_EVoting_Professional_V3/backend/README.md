# NaijaVote API — v3

Conceptual prototype backend. Not an authorised INEC or government system.

## Setup

```bash
npm install
cp .env.example .env
# edit .env: set JWT_SECRET to a long random value (see the comment in the file)
npm run bootstrap   # creates the one and only initial Super Admin account
npm start
```

The database lives in `backend/data/evoting.db` (SQLite, WAL mode) and
persists across restarts — nothing resets when the process stops, unlike
the previous in-memory demo store.

## There is no built-in administrator account

`npm run bootstrap` is the only way a `SUPER_ADMIN` account is created. It
either reads `BOOTSTRAP_SUPER_ADMIN_EMAIL` / `BOOTSTRAP_SUPER_ADMIN_PASSWORD`
from your environment, or prompts for them interactively with the password
hidden. It refuses to run a second time once a Super Admin already exists.
Nothing resembling a credential ever appears in source code.

Every other administrative account is provisioned *inside* the app by
someone already above it in the hierarchy (see below), and is issued a
one-time activation link rather than a starting password.

## Administrative hierarchy

```
SUPER_ADMIN            platform owner — appoints the INEC Chairman
   └─ INEC_CHAIRMAN         national authority — appoints the 6 Zonal Commissioners
         └─ ZONAL_COMMISSIONER      one per geopolitical zone — appoints State Electoral Officers in-zone
               └─ STATE_ELECTORAL_OFFICER   one per state — appoints LGA Electoral Officers in-state
                     └─ LGA_ELECTORAL_OFFICER   local government level

SECURITY_AUDIT_OFFICER   cross-cutting, read-only audit access at every level
VOTER                    casts a ballot
```

This mirrors Nigeria's federal / state / local government structure: a
Zonal Commissioner can only appoint officers for states inside their own
zone, and a State Electoral Officer can only appoint officers inside their
own state — enforced server-side in `rbac.js`, not just hidden in the UI.

## Authentication & session model

- Passwords are hashed with bcrypt (cost 12); never stored or logged in the clear.
- Failed logins are rate-limited and lock the account for 15 minutes after 5 misses.
- Login/registration errors are deliberately generic ("Invalid credentials")
  so the endpoint can't be used to enumerate which emails have accounts.
- Sessions are database-backed, not just a signed token: each login creates
  a row in `sessions`, and every authenticated request checks it hasn't been
  revoked. Revoking an official's access immediately kills any session they
  currently hold — they don't have to wait for a token to expire.

### Mandatory MFA for every privileged role

`SUPER_ADMIN`, `INEC_CHAIRMAN`, both regional/state senior roles
(`ZONAL_COMMISSIONER`, `STATE_ELECTORAL_OFFICER`), and `SECURITY_AUDIT_OFFICER`
cannot obtain a session without MFA enabled — login walks them straight
through TOTP setup first if it isn't on yet (`rbac.js: MFA_MANDATORY_ROLES`).
`LGA_ELECTORAL_OFFICER` and `VOTER` can turn MFA on for themselves from
Settings but aren't forced to, reflecting their lower blast radius.

### Step-up verification for sensitive actions

Being logged in — even with MFA — is not enough on its own to appoint or
revoke an official, or to publish a candidate. Those three actions require
a **step-up token**: a short-lived (5 minute) proof that the account holder
just re-entered a current MFA code, requested via `POST /api/auth/step-up`
and sent back as an `X-Step-Up-Token` header. This means a session left
open and unattended, or a stolen bearer token, is not by itself enough to
make an appointment or a revocation — a live MFA code is required for that
specific action, not just at login. See `requireStepUp` in
`auth-middleware.js` and its use on `/api/officials`,
`/api/officials/:id/revoke`, and `/api/candidates` in `server.js`.

## Candidates & elections

Federal-level candidates are seeded once on first run and can be replaced
by `INEC_CHAIRMAN` / `SUPER_ADMIN` through `POST /api/candidates` before a
real election window — nothing about the ballot is hard-coded.

## Still out of scope for this prototype

Independent security/cryptographic review, vote-secrecy guarantees beyond
"the ballot table doesn't record who cast which vote", accessibility audit,
and legal authorisation. None of this is a substitute for those.
