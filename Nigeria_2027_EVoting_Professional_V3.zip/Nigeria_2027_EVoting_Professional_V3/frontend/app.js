// The frontend and backend run as two separate forwarded ports in
// Codespaces (and similar cloud dev environments), each on its own
// hostname — "localhost" in the browser means the device you're holding,
// not the container, so it can never reach a backend on another port
// there. Resolve the real API origin at runtime instead of hardcoding it.
const API = (() => {
  const { protocol, hostname, host } = window.location;
  if (hostname === 'localhost' || hostname === '127.0.0.1') {
    return 'http://localhost:4000/api'; // plain local dev on one machine
  }
  // GitHub Codespaces forwards each port as its own hostname, of the form
  // <codespace-name>-<port>.app.github.dev — swap the port segment to 4000.
  if (/-\d+\.app\.github\.dev$/.test(hostname)) {
    return `${protocol}//${hostname.replace(/-\d+(\.app\.github\.dev)$/, '-4000$1')}/api`;
  }
  // Gitpod and similar tools put the port as a numeric prefix on the host.
  if (/^\d+-/.test(host)) {
    return `${protocol}//${host.replace(/^\d+-/, '4000-')}/api`;
  }
  // Fallback: same host, different port (works if both are served together).
  return `${protocol}//${hostname}:4000/api`;
})();

let session = null; // { token, user }
let level = 'Federal';
let candidate = null;
let pendingPreAuth = null; // { token, purpose: 'mfa_login' | 'mfa_setup' }
let jurisdictions = { zones: [], states: [] };
let stepUp = null; // { token, expiresAt } — short-lived proof of a fresh MFA code
let stepUpPendingAction = null;

const APPOINTABLE = {
  SUPER_ADMIN: ['INEC_CHAIRMAN', 'SECURITY_AUDIT_OFFICER'],
  INEC_CHAIRMAN: ['ZONAL_COMMISSIONER', 'SECURITY_AUDIT_OFFICER'],
  ZONAL_COMMISSIONER: ['STATE_ELECTORAL_OFFICER'],
  STATE_ELECTORAL_OFFICER: ['LGA_ELECTORAL_OFFICER']
};
const ADMIN_ROLES = ['SUPER_ADMIN', 'INEC_CHAIRMAN', 'ZONAL_COMMISSIONER', 'STATE_ELECTORAL_OFFICER', 'LGA_ELECTORAL_OFFICER', 'SECURITY_AUDIT_OFFICER'];

function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2600);
}

// ---------------- language (draft translations, see i18n.js) ----------------

function currentLang() {
  return localStorage.getItem('nv_lang') || 'en';
}

function applyLanguage(lang) {
  if (!STRINGS[lang]) lang = 'en';
  localStorage.setItem('nv_lang', lang);
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const text = STRINGS[lang][el.dataset.i18n] || STRINGS.en[el.dataset.i18n];
    if (text == null) return;
    const first = el.firstChild;
    if (el.children.length && first && first.nodeType === Node.TEXT_NODE) {
      first.textContent = text; // label wrapping an <input>/<select> — only replace the leading label text
    } else if (!el.children.length) {
      el.textContent = text;
    }
  });
  document.getElementById('translationNoticeAuth')?.classList.toggle('hidden', lang === 'en');
  document.getElementById('translationNoticeApp')?.classList.toggle('hidden', lang === 'en');
  document.querySelectorAll('.lang-select').forEach((sel) => { if (sel.value !== lang) sel.value = lang; });
}

function populateLanguageSelects() {
  document.querySelectorAll('.lang-select').forEach((sel) => {
    sel.innerHTML = LANGUAGES.map((l) => `<option value="${l.code}">${l.label}</option>`).join('');
    sel.value = currentLang();
    sel.addEventListener('change', () => applyLanguage(sel.value));
  });
}

// ---------------- offline ballot queue ----------------
// A vote that can't reach the server (connectivity drop mid-submission,
// common on low-bandwidth mobile networks) is queued on the device and
// retried automatically once the network returns. This trades a small,
// documented privacy cost — the ballot choice sits briefly in this
// browser's local storage rather than nowhere — for not losing a citizen's
// vote to a dropped connection. See docs/README.md for that trade-off.

const OFFLINE_KEY = 'nv_pending_vote';
const getPendingVote = () => { try { return JSON.parse(localStorage.getItem(OFFLINE_KEY) || 'null'); } catch { return null; } };
const setPendingVote = (v) => localStorage.setItem(OFFLINE_KEY, JSON.stringify(v));
const clearPendingVote = () => localStorage.removeItem(OFFLINE_KEY);

function updateOfflineBanner() {
  const banner = document.getElementById('offlineBanner');
  if (!banner) return;
  banner.classList.toggle('hidden', navigator.onLine && !getPendingVote());
}

async function flushPendingVote() {
  const pending = getPendingVote();
  if (!pending || !session) { updateOfflineBanner(); return; }
  try {
    const d = await api('/votes', { method: 'POST', body: JSON.stringify(pending) });
    clearPendingVote();
    document.getElementById('reference').textContent = d.confirmation;
    document.getElementById('receiptHash').textContent = d.receiptHash;
    document.getElementById('ledgerIndex').textContent = d.ledgerIndex;
    const lang = currentLang();
    document.getElementById('confirmationLead').textContent = STRINGS[lang]?.confirmation_lead || STRINGS.en.confirmation_lead;
    toast('Your queued ballot has been submitted.');
    screen('confirmation');
  } catch (e) {
    if (e.offline) { updateOfflineBanner(); return; }
    clearPendingVote(); // server rejected it outright (e.g. already voted another way) — nothing more to retry
    toast(e.message);
  }
  updateOfflineBanner();
}

window.addEventListener('online', flushPendingVote);
window.addEventListener('offline', updateOfflineBanner);

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
}

async function api(path, opt = {}) {
  const headers = { 'Content-Type': 'application/json', ...(opt.headers || {}) };
  if (session?.token) headers.Authorization = 'Bearer ' + session.token;
  if (stepUpValid()) headers['X-Step-Up-Token'] = stepUp.token;
  let r;
  try {
    r = await fetch(API + path, { ...opt, headers });
  } catch {
    const offlineErr = new Error("You appear to be offline.");
    offlineErr.offline = true;
    throw offlineErr;
  }
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.message || 'Request failed');
  return d;
}

function stepUpValid() {
  return stepUp && new Date(stepUp.expiresAt) > new Date();
}

// Runs `action` immediately if a fresh MFA confirmation is already on file
// (within the last 5 minutes); otherwise prompts for a code first, then
// runs `action` once that code is verified. Used for appointing/revoking
// officials and publishing candidates — sensitive actions that a live
// session alone should not be enough to perform.
function withStepUp(action) {
  if (stepUpValid()) { action(); return; }
  stepUpPendingAction = action;
  document.getElementById('stepUpModal').classList.remove('hidden');
  document.getElementById('stepUpCode').value = '';
  document.getElementById('stepUpMsg').classList.add('hidden');
}

document.getElementById('stepUpCancel').addEventListener('click', () => {
  stepUpPendingAction = null;
  document.getElementById('stepUpModal').classList.add('hidden');
});

document.getElementById('stepUpConfirm').addEventListener('click', async () => {
  const msg = document.getElementById('stepUpMsg');
  try {
    const d = await api('/auth/step-up', {
      method: 'POST',
      body: JSON.stringify({ code: document.getElementById('stepUpCode').value })
    });
    stepUp = { token: d.stepUpToken, expiresAt: d.expiresAt };
    document.getElementById('stepUpModal').classList.add('hidden');
    const action = stepUpPendingAction;
    stepUpPendingAction = null;
    action && action();
  } catch (err) {
    msg.textContent = err.message;
    msg.classList.remove('hidden');
  }
});

function roleLabel(role) {
  return (role || '').replaceAll('_', ' ').replace(/\w\S*/g, w => w[0] + w.slice(1).toLowerCase());
}

// ---------------- public transparency (no login required) ----------------

const LEVELS = ['Federal', 'State', 'Local Government'];

async function sha256Hex(text) {
  const bytes = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, '0')).join('');
}

async function renderTally(container) {
  container.innerHTML = '<p class="muted">Loading…</p>';
  const blocks = await Promise.all(LEVELS.map(async (lvl) => {
    try {
      const d = await api('/public/tally?level=' + encodeURIComponent(lvl));
      if (!d.revealed) {
        return `<div class="tally-bar-row"><b>${lvl}</b>
          <p class="tally-pending">${d.totalVotes} of ${d.threshold} ballots recorded — the breakdown by candidate appears once turnout clears this level's privacy threshold.</p></div>`;
      }
      const max = Math.max(1, ...d.results.map(r => r.votes));
      const bars = d.results.map(r => `
        <div class="tally-bar-row">
          <div class="tally-bar-label"><span>${r.name} · ${r.party}</span><span>${r.votes}</span></div>
          <div class="tally-bar-track"><div class="tally-bar-fill" style="width:${(r.votes / max) * 100}%"></div></div>
        </div>`).join('');
      return `<p class="ledger-title">${lvl} · ${d.totalVotes} recorded</p>${bars}`;
    } catch { return `<p class="muted">${lvl}: unavailable.</p>`; }
  }));
  container.innerHTML = blocks.join('<hr style="border:none;border-top:1px solid var(--line);margin:16px 0">');
}

async function verifyLedger(resultEl) {
  resultEl.classList.remove('hidden');
  resultEl.textContent = 'Fetching and recomputing the chain…';
  try {
    const d = await api('/public/ledger');
    let prev = d.genesisHash;
    for (const entry of d.entries) {
      const expected = await sha256Hex(`${entry.id}|${entry.candidateId}|${entry.level}|${entry.contest}|${entry.time}|${prev}`);
      if (expected !== entry.receiptHash || entry.prevHash !== prev) {
        resultEl.textContent = `Chain broken at ledger entry #${entry.index} — this would indicate tampering.`;
        return;
      }
      prev = entry.receiptHash;
    }
    resultEl.textContent = `Verified: all ${d.entries.length} recorded ballots form an unbroken, untampered chain.`;
  } catch (e) {
    resultEl.textContent = 'Could not verify: ' + e.message;
  }
}

document.getElementById('publicResultsLink').addEventListener('click', () => {
  document.getElementById('publicOverlay').classList.remove('hidden');
  renderTally(document.getElementById('publicTallyBox'));
});
document.getElementById('publicClose').addEventListener('click', () =>
  document.getElementById('publicOverlay').classList.add('hidden'));
document.getElementById('verifyLedgerBtn').addEventListener('click', () =>
  verifyLedger(document.getElementById('ledgerVerifyResult')));
document.getElementById('observerVerifyBtn').addEventListener('click', () =>
  verifyLedger(document.getElementById('observerVerifyResult')));

async function exportLedgerCsv() {
  const d = await api('/public/ledger');
  const header = 'index,level,contest,candidate,time,prevHash,receiptHash';
  const rows = d.entries.map(e =>
    [e.index, e.level, e.contest, e.candidateLabel, e.time, e.prevHash, e.receiptHash]
      .map(v => `"${String(v).replaceAll('"', '""')}"`).join(','));
  const blob = new Blob([header + '\n' + rows.join('\n')], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'naijavote-public-ledger.csv';
  a.click();
  URL.revokeObjectURL(url);
}
document.getElementById('publicExportBtn').addEventListener('click', () => exportLedgerCsv().catch((e) => toast(e.message)));
document.getElementById('observerExportBtn').addEventListener('click', () => exportLedgerCsv().catch((e) => toast(e.message)));

// ---------------- auth gate ----------------

document.querySelectorAll('.auth-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    ['loginForm', 'registerForm', 'activateForm', 'mfaForm', 'mfaSetupForced'].forEach(id =>
      document.getElementById(id).classList.add('hidden'));
    document.getElementById(tab.dataset.auth === 'login' ? 'loginForm'
      : tab.dataset.auth === 'register' ? 'registerForm' : 'activateForm').classList.remove('hidden');
  });
});

document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = document.getElementById('loginMsg');
  try {
    const d = await api('/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        email: document.getElementById('loginEmail').value,
        password: document.getElementById('loginPassword').value
      })
    });
    if (d.mfaSetupRequired) {
      pendingPreAuth = { token: d.preAuthToken, purpose: 'mfa_setup' };
      const setup = await api('/auth/mfa/setup-with-preauth', { method: 'POST', body: JSON.stringify({ preAuthToken: d.preAuthToken }) });
      pendingPreAuth = { token: setup.preAuthToken, purpose: 'mfa_setup_confirm' };
      document.getElementById('forcedSecretText').textContent = setup.secret;
      document.getElementById('forcedOtpLink').href = setup.otpauthUrl;
      document.getElementById('loginForm').classList.add('hidden');
      document.getElementById('mfaSetupForced').classList.remove('hidden');
      return;
    }
    if (d.mfaRequired) {
      pendingPreAuth = { token: d.preAuthToken, purpose: 'mfa_login' };
      document.getElementById('loginForm').classList.add('hidden');
      document.getElementById('mfaForm').classList.remove('hidden');
      return;
    }
    startSession(d);
  } catch (err) {
    msg.textContent = err.message;
    msg.classList.remove('hidden');
  }
});

document.getElementById('mfaForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = document.getElementById('mfaMsg');
  try {
    const d = await api('/auth/mfa/verify', {
      method: 'POST',
      body: JSON.stringify({ preAuthToken: pendingPreAuth.token, code: document.getElementById('mfaCode').value })
    });
    startSession(d);
  } catch (err) {
    msg.textContent = err.message;
    msg.classList.remove('hidden');
  }
});

document.getElementById('forcedMfaConfirm').addEventListener('click', async () => {
  const msg = document.getElementById('forcedMfaMsg');
  try {
    const d = await api('/auth/mfa/confirm-with-preauth', {
      method: 'POST',
      body: JSON.stringify({ preAuthToken: pendingPreAuth.token, code: document.getElementById('forcedMfaCode').value })
    });
    startSession(d);
  } catch (err) {
    msg.textContent = err.message;
    msg.classList.remove('hidden');
  }
});

document.getElementById('registerForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = document.getElementById('regMsg');
  try {
    const d = await api('/auth/signup', {
      method: 'POST',
      body: JSON.stringify({
        email: document.getElementById('regEmail').value,
        password: document.getElementById('regPassword').value,
        nin: document.getElementById('regNin').value,
        voterCard: document.getElementById('regVoterCard').value
      })
    });
    startSession(d);
  } catch (err) {
    msg.textContent = err.message;
    msg.classList.remove('hidden');
  }
});

document.getElementById('activateForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = document.getElementById('actMsg');
  try {
    const d = await api('/auth/activate', {
      method: 'POST',
      body: JSON.stringify({
        token: document.getElementById('actToken').value.trim(),
        password: document.getElementById('actPassword').value
      })
    });
    msg.textContent = d.message + ' Switch to the Log in tab.';
    msg.classList.remove('hidden');
  } catch (err) {
    msg.textContent = err.message;
    msg.classList.remove('hidden');
  }
});

function startSession(d) {
  session = { token: d.token, user: d.user };
  sessionStorage.setItem('nv_session', JSON.stringify(session));
  enterApp();
}

document.getElementById('logoutBtn').addEventListener('click', async () => {
  try { await api('/auth/logout', { method: 'POST' }); } catch {}
  session = null;
  sessionStorage.removeItem('nv_session');
  document.getElementById('appShell').classList.add('hidden');
  document.getElementById('authGate').classList.remove('hidden');
});

// ---------------- app shell ----------------

function enterApp() {
  document.getElementById('authGate').classList.add('hidden');
  document.getElementById('appShell').classList.remove('hidden');
  document.getElementById('sessionRole').textContent = roleLabel(session.user.role);
  document.getElementById('sessionEmail').textContent = session.user.email;

  const isAdmin = ADMIN_ROLES.includes(session.user.role);
  let firstVisible = 'observer';
  document.querySelectorAll('.rail-item[data-roles]').forEach(el => {
    const allowed = el.dataset.roles.split(',').includes(session.user.role);
    el.classList.toggle('hidden', !allowed);
    if (allowed && firstVisible === 'observer') firstVisible = el.dataset.screen;
  });

  const lang = currentLang();
  const t = STRINGS[lang] || STRINGS.en;
  document.getElementById('dashName').textContent = session.user.email;
  document.getElementById('dashVerified').textContent = session.user.verified ? t.status_verified : t.status_not_verified;
  document.getElementById('dashBallot').textContent = session.user.hasVoted ? t.status_submitted : t.status_not_submitted;

  screen(isAdmin ? (firstVisible === 'observer' ? 'observer' : firstVisible) : 'dashboard');
  loadStats();
  updateOfflineBanner();
  flushPendingVote();
}

function screen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id)?.classList.add('active');
  document.querySelectorAll('.rail-item').forEach(r => r.classList.toggle('active', r.dataset.screen === id));
  window.scrollTo(0, 0);
  if (id === 'officials') loadOfficials();
  if (id === 'audit') loadAudit();
  if (id === 'observer') renderTally(document.getElementById('observerTallyBox'));
  if (id === 'ballot') loadCandidates();
  if (id === 'settings') loadMfaStatus();
  if (id === 'officialSignup') prepareOfficialForm();
}

document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-screen]');
  if (b) { e.preventDefault(); screen(b.dataset.screen); }
});

document.querySelectorAll('[data-election]').forEach(row => row.addEventListener('click', () => {
  level = row.dataset.election;
  document.getElementById('chosenLevel').textContent = level;
  document.getElementById('contestBox').classList.remove('hidden');
  screen('elections');
}));

document.getElementById('continueBallot').addEventListener('click', () => {
  document.getElementById('ballotMeta').textContent = level + ' Election · ' + document.getElementById('contest').value;
  screen('ballot');
});

// ---------------- verification ----------------

document.querySelectorAll('.verify-btn').forEach(b => b.addEventListener('click', async () => {
  try {
    const d = await api('/verification/demo', { method: 'POST', body: JSON.stringify({ type: b.dataset.type }) });
    b.textContent = 'Verified';
    b.disabled = true;
    toast(d.message);
  } catch (err) { toast(err.message); }
}));

// ---------------- ballot ----------------

async function loadCandidates() {
  const g = document.getElementById('candidateGrid');
  try {
    const d = await api('/elections/candidates?level=' + encodeURIComponent(level));
    g.innerHTML = d.candidates.map(c =>
      `<button class="candidate" data-id="${c.id}"><img src="${c.image}" alt=""><span><b>${c.name}</b><small>${c.party}</small></span><i class="radio"></i></button>`
    ).join('') || '<p class="muted">No candidates published for this level yet.</p>';
    g.querySelectorAll('.candidate').forEach(x => x.onclick = () => {
      g.querySelectorAll('.candidate').forEach(y => y.classList.remove('selected'));
      x.classList.add('selected');
      candidate = x.dataset.id;
      const s = document.getElementById('selectionText');
      s.textContent = x.querySelector('b').textContent;
      s.className = 'selection-chosen';
    });
  } catch (e) { g.innerHTML = `<p class="muted">${e.message}</p>`; }
}

document.getElementById('submitVote').addEventListener('click', async () => {
  if (!candidate) return toast('Select a candidate first.');
  const payload = { electionLevel: level, contest: document.getElementById('contest').value, candidateId: candidate };
  try {
    const d = await api('/votes', { method: 'POST', body: JSON.stringify(payload) });
    document.getElementById('reference').textContent = d.confirmation;
    document.getElementById('receiptHash').textContent = d.receiptHash;
    document.getElementById('ledgerIndex').textContent = d.ledgerIndex;
    screen('confirmation');
    loadStats();
  } catch (e) {
    if (e.offline) {
      setPendingVote(payload);
      updateOfflineBanner();
      const lang = currentLang();
      document.getElementById('confirmationLead').textContent = STRINGS[lang]?.confirmation_queued || STRINGS.en.confirmation_queued;
      document.getElementById('reference').textContent = 'PENDING — QUEUED OFFLINE';
      document.getElementById('receiptHash').textContent = 'Issued once submitted';
      document.getElementById('ledgerIndex').textContent = '—';
      screen('confirmation');
      return;
    }
    const m = document.getElementById('voteMsg');
    m.textContent = e.message;
    m.classList.remove('hidden');
  }
});

document.getElementById('retrySyncBtn')?.addEventListener('click', flushPendingVote);

// ---------------- officials / governance ----------------

async function ensureJurisdictions() {
  if (jurisdictions.zones.length) return;
  try { jurisdictions = await api('/reference/jurisdictions'); } catch {}
}

async function prepareOfficialForm() {
  await ensureJurisdictions();
  const roleSelect = document.getElementById('officialRole');
  const options = APPOINTABLE[session.user.role] || [];
  roleSelect.innerHTML = options.map(r => `<option value="${r}">${roleLabel(r)}</option>`).join('')
    || '<option value="">No roles available to your account</option>';

  const zoneSelect = document.getElementById('officialZone');
  zoneSelect.innerHTML = jurisdictions.zones.map(z => `<option>${z}</option>`).join('');

  const stateSelect = document.getElementById('officialState');
  const statesInScope = session.user.role === 'ZONAL_COMMISSIONER'
    ? jurisdictions.states.filter(s => true) // server enforces the real zone check; UI still lists all for simplicity
    : jurisdictions.states;
  stateSelect.innerHTML = statesInScope.map(s => `<option>${s}</option>`).join('');

  updateOfficialFieldVisibility();
  roleSelect.onchange = updateOfficialFieldVisibility;
  document.getElementById('activationResult').classList.add('hidden');
}

function updateOfficialFieldVisibility() {
  const role = document.getElementById('officialRole').value;
  document.getElementById('zoneField').classList.toggle('hidden', role !== 'ZONAL_COMMISSIONER');
  document.getElementById('stateField').classList.toggle('hidden', role !== 'STATE_ELECTORAL_OFFICER');
  document.getElementById('lgaField').classList.toggle('hidden', role !== 'LGA_ELECTORAL_OFFICER');
}

document.getElementById('officialForm').addEventListener('submit', (e) => {
  e.preventDefault();
  withStepUp(submitOfficialForm);
});

async function submitOfficialForm() {
  const msg = document.getElementById('officialMsg');
  msg.classList.add('hidden');
  const role = document.getElementById('officialRole').value;
  const payload = {
    name: document.getElementById('officialName').value,
    email: document.getElementById('officialEmail').value,
    role,
    zone: role === 'ZONAL_COMMISSIONER' ? document.getElementById('officialZone').value : undefined,
    state: role === 'STATE_ELECTORAL_OFFICER' ? document.getElementById('officialState').value
         : role === 'LGA_ELECTORAL_OFFICER' ? session.user.state : undefined,
    lga: role === 'LGA_ELECTORAL_OFFICER' ? document.getElementById('officialLga').value : undefined
  };
  try {
    const d = await api('/officials', { method: 'POST', body: JSON.stringify(payload) });
    msg.textContent = 'Account created for ' + d.official.email + '.';
    msg.classList.remove('hidden');
    document.getElementById('activationTokenText').textContent = d.activationToken;
    document.getElementById('activationResult').classList.remove('hidden');
    document.getElementById('officialForm').reset();
  } catch (err) {
    msg.textContent = err.message;
    msg.classList.remove('hidden');
  }
}

async function loadOfficials() {
  const body = document.getElementById('officialList');
  try {
    const d = await api('/officials');
    body.innerHTML = d.officials.map(o => {
      const jurisdiction = [o.zone, o.state, o.lga].filter(Boolean).join(' · ') || 'National';
      return `<tr>
        <td><b>${o.email}</b></td>
        <td>${roleLabel(o.role)}</td>
        <td>${jurisdiction}</td>
        <td><span class="status-pill">${o.status}</span></td>
        <td>${o.status === 'ACTIVE' || o.status === 'PENDING_ACTIVATION'
              ? `<button class="revoke" data-id="${o.id}">Revoke</button>` : '—'}</td>
      </tr>`;
    }).join('') || '<tr><td colspan="5" class="muted">No officials in your jurisdiction yet.</td></tr>';
    body.querySelectorAll('.revoke').forEach(btn => btn.onclick = () => {
      if (!confirm('Revoke this official account? This immediately ends any active session.')) return;
      withStepUp(async () => {
        try {
          await api('/officials/' + btn.dataset.id + '/revoke', { method: 'POST' });
          toast('Access revoked; audit retained.');
          loadOfficials();
        } catch (e) { toast(e.message); }
      });
    });
  } catch (e) {
    body.innerHTML = `<tr><td colspan="5" class="muted">${e.message}</td></tr>`;
  }
}

async function loadAudit() {
  try {
    const d = await api('/audit');
    document.getElementById('auditTable').innerHTML = d.events.map(x =>
      `<tr><td>${new Date(x.time).toLocaleString()}</td><td>${x.event}</td><td>${x.actor}</td><td><span class="status-pill">${x.result}</span></td></tr>`
    ).join('') || '<tr><td colspan="4" class="muted">No audit events yet.</td></tr>';
  } catch (e) { toast(e.message); }
}

async function loadStats() {
  try { await api('/public/stats'); } catch {}
}

// ---------------- settings / self-service MFA ----------------

async function loadMfaStatus() {
  const line = document.getElementById('mfaStatusLine');
  const enabled = session.user.mfaEnabled;
  line.textContent = enabled
    ? 'Multi-factor authentication is active on this account.'
    : 'Multi-factor authentication is not yet enabled on this account.';
  document.getElementById('settingsMfaStart').classList.toggle('hidden', enabled);
}

document.getElementById('settingsMfaStart').addEventListener('click', async () => {
  try {
    const d = await api('/auth/mfa/setup', { method: 'POST' });
    document.getElementById('settingsSecretText').textContent = d.secret;
    document.getElementById('settingsOtpLink').href = d.otpauthUrl;
    document.getElementById('mfaSetupBlock').classList.remove('hidden');
    document.getElementById('settingsMfaStart').classList.add('hidden');
  } catch (e) { toast(e.message); }
});

document.getElementById('settingsMfaConfirm').addEventListener('click', async () => {
  const msg = document.getElementById('settingsMfaMsg');
  try {
    const d = await api('/auth/mfa/confirm', {
      method: 'POST',
      body: JSON.stringify({ code: document.getElementById('settingsMfaCode').value })
    });
    session.user.mfaEnabled = true;
    sessionStorage.setItem('nv_session', JSON.stringify(session));
    msg.textContent = d.message;
    msg.classList.remove('hidden');
    document.getElementById('mfaSetupBlock').classList.add('hidden');
    loadMfaStatus();
  } catch (e) {
    msg.textContent = e.message;
    msg.classList.remove('hidden');
  }
});

// ---------------- boot ----------------

(function boot() {
  populateLanguageSelects();
  applyLanguage(currentLang());
  updateOfflineBanner();
  const saved = sessionStorage.getItem('nv_session');
  if (saved) {
    try { session = JSON.parse(saved); enterApp(); return; } catch {}
  }
})();
