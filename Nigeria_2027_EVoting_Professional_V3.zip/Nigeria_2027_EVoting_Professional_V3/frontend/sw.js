// Caches only the static app shell (markup, styles, script, the language
// dictionary, the emblem) so the interface itself still loads with no
// connection. It deliberately never touches anything under /api/ — vote
// submission, login, the public ledger and so on always go straight to
// the network, so this cache can never serve stale or sensitive data.
// The offline *voting* flow (queue-and-retry) lives in app.js, not here.

const CACHE_NAME = 'naijavote-shell-v1';
const SHELL_FILES = [
  './',
  './index.html',
  './styles.css',
  './app.js',
  './i18n.js',
  './manifest.json',
  './nigeria-emblem.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_FILES)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Never intercept API traffic — always hit the network so the app can
  // tell the difference between "offline" and "server said no", and so
  // nothing sensitive is ever read from a cache.
  if (url.pathname.startsWith('/api/')) return;
  if (event.request.method !== 'GET') return;

  event.respondWith(
    caches.match(event.request).then((cached) =>
      cached || fetch(event.request).then((response) => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
        return response;
      }).catch(() => cached)
    )
  );
});
