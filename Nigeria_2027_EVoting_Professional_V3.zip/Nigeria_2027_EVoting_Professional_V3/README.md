# Nigeria 2027 E-Voting — Professional V3

A restructured conceptual prototype: a distinct civic visual identity, a
real federal/state/local administrative hierarchy, and a backend rebuilt
around persistent storage and genuine authentication rather than a demo
in-memory store.

This is a conceptual prototype only. It is not authorised by INEC or the
Nigerian government, and is not suitable for a real election without
independent security, cryptographic, legal, accessibility and operational
review.

## What changed from V2

- **No hard-coded administrator.** There used to be an `admin@demo.local` /
  `DemoAdmin123!` account created automatically in source code. It's gone.
  The only way to get a first administrator now is `npm run bootstrap`,
  which creates a `SUPER_ADMIN` from environment-managed secrets or an
  interactive hidden-password prompt — see `backend/README.md`.
- **Persistent database.** Accounts, votes, candidates and the audit log
  now live in a SQLite file (`backend/data/evoting.db`) instead of
  in-memory `Map()`s. Restarting the server no longer wipes every account.
- **Real administrative hierarchy.** `SUPER_ADMIN → INEC_CHAIRMAN → one
  Zonal Commissioner per geopolitical zone → State Electoral Officers →
  LGA Electoral Officers`, enforced server-side in `backend/rbac.js`, plus
  a read-only `SECURITY_AUDIT_OFFICER` role. A Zonal Commissioner can only
  appoint officers inside their own zone; a State Electoral Officer only
  inside their own state.
- **Genuine authentication.** bcrypt password hashing, account lockout
  after repeated failures, database-backed sessions that can be revoked
  immediately (not just left to expire), mandatory TOTP MFA for every
  privileged role (Super Admin, national and regional/state administrators,
  the security/audit role), and a separate step-up MFA check required
  at the moment of any sensitive action — appointing or revoking an
  official, or publishing a candidate — not just at login.
- **No default passwords for officials either.** A newly appointed official
  gets a one-time activation link, not a starting password, and can't log
  in until they've set their own.
- **Redesigned frontend.** A civic register/gazette identity — masthead,
  serif display type, ledger-style lists and tables — replacing the
  generic rounded-card dashboard look, plus a real login screen instead
  of the previous "tap the avatar five times" admin shortcut.
- **Public, self-verifying vote ledger.** A hash-chained, no-login public
  ledger anyone can independently verify in their own browser, plus a
  live per-candidate tally gated by a small turnout threshold so it can
  never de-anonymize a near-empty local contest.
- **Works offline; installable.** A small PWA (service worker + web
  manifest) whose shell still loads with no connection, and a ballot
  submitted while offline is queued on-device and retried automatically —
  with the privacy trade-off that involves stated plainly in
  `docs/README.md`.
- **Real multilingual UI.** English, Hausa, Yorùbá, Igbo, and Nigerian
  Pidgin, switchable live — genuine working translations, flagged in-app
  as pending native-speaker review rather than presented as finished.

## Start in GitHub Codespaces (or any two terminals)

### Terminal 1 — backend
```bash
cd backend
npm install
cp .env.example .env   # then edit JWT_SECRET
npm run bootstrap      # create the first Super Admin
npm start
```

### Terminal 2 — frontend
```bash
cd frontend
python3 -m http.server 5500
```

Open port **5500**. Log in with the Super Admin account you just created —
you'll be walked through MFA setup on first login, since that role requires
it. From there, appoint the INEC Chairman, who appoints the six Zonal
Commissioners, and so on down the hierarchy.

### A note on Codespaces networking

The frontend figures out where the backend lives at runtime rather than
assuming `localhost` — in Codespaces, "localhost" in your browser means
your own device, not the container, so a hardcoded address would never
reach the backend. If you ever see "You appear to be offline" even though
the backend terminal shows it's running, check the **Ports** tab: both
4000 and 5500 need to be forwarded (usually automatic once each server
starts). If requests still fail, try setting port 4000's visibility to
Public from that same tab, then reload the page.

See `backend/README.md` for the full security model and `docs/README.md`
for the design notes behind the frontend rebuild.
