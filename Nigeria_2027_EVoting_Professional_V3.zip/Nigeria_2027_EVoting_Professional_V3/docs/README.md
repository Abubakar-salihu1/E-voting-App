# Professional V3 design notes

## What was wrong with V2's look

The previous interface was the generic SaaS-dashboard kit: identical
rounded cards with the same soft shadow regardless of what they held,
tracked-out ALL-CAPS "eyebrow" labels stacked above nearly every section,
arrows appended to every button, and a sidebar that read like any
admin-tool template — nothing about it said "national election register."

## Standout feature: a public, no-login, self-verifying ledger

The most credible thing an e-voting concept can demonstrate isn't a nicer
dashboard — it's letting a stranger check its own honesty without asking
anyone's permission. So every recorded ballot is chained into an
append-only ledger: each entry's hash commits to the one before it
(`ledgerReceipt()` in `backend/server.js`), and `GET /api/public/ledger`
publishes the whole chain with zero authentication required. Anyone —
press, party agents, an international observer, a curious citizen — can
click "Recompute & verify chain" and have their own browser (via
`crypto.subtle.digest`, not a server-side claim) confirm that nothing in
the record has been altered after the fact. If a single past entry were
edited, every hash after it would stop matching, and the check fails
visibly.

This also finally delivers a requirement from earlier in the project that
V2 only partially met: a live public vote tally, visible with no login at
all. `GET /api/public/tally` breaks that down by candidate — but only once
a level clears a small turnout threshold (`PUBLIC_TALLY_THRESHOLD`,
default 5), so a near-empty local contest can't be de-anonymized just by
watching the running total change in real time. Below the threshold, the
public only sees a running count, not a breakdown.

None of this weakens ballot secrecy, because the `votes` table has never
had a voter-identity column to begin with — publishing an anonymous row
doesn't create a link to whoever cast it. A voter's confirmation screen
shows their own receipt hash and ledger position precisely so they can
look themselves up in that same public ledger afterwards, without anyone
else being able to tell which entry is theirs.

## The visual rebuild

A civic register / government-gazette identity, built around the actual
subject matter — a national election system — rather than a dashboard
template:

- **Colour:** a warm gazette paper background (`#F6F1E3`) instead of pure
  white or a SaaS off-white, deep flag green (`#0B6B3A` / `#063F23`) for
  authority, a muted brass gold (`#A9812E`) for the one sequence that
  actually earns numbering, restrained rule lines instead of drop shadows.
- **Type:** Source Serif 4 for headings — the register/gazette has the
  weight of an official document — paired with IBM Plex Sans for body
  text and controls, a deliberate pairing rather than a single default
  sans everywhere.
- **Layout:** a masthead (emblem, "Federal Republic of Nigeria", title)
  standing in for a generic top bar; a slim text-only registry rail
  instead of an icon-pill sidebar; ledger-style rule-separated rows and
  tables instead of repeated card grids. The one numbered list that
  remains — Federal / State / Local Government — is numbered because it
  really is the constitutional sequence of government tiers, not
  decoration.
- **Copy:** eyebrow labels and eyebrow-style meta lines were removed
  wherever they weren't communicating something factual (the masthead's
  "Federal Republic of Nigeria" line stays, because it's literally true,
  not decorative chrome).

## Functional changes that support the new hierarchy

- A real login screen (with MFA where required) replaces the previous
  "tap the avatar five times" admin shortcut.
- The officials register now shows each official's actual jurisdiction
  (zone / state / LGA) alongside their role, and the "appoint an official"
  form only offers the roles the signed-in account is actually allowed to
  create, with the matching jurisdiction fields appearing dynamically.
- Navigation items are shown only to the roles the backend actually grants
  access to — a Security & Audit Officer sees the audit trail and the
  officials register but not an "appoint official" action; an LGA
  Electoral Officer sees neither, since their role doesn't carry that
  authority.

## Further ideas, not built here

Worth knowing about even though they aren't in this package, so nothing
gets presented as done that isn't:

- **Independent cryptographic review** of the hash-chain design above
  before treating "tamper-evident" as a legal or forensic guarantee.
- **Turnout-anomaly alerts** (e.g. a jurisdiction's ballots exceeding its
  registered voters) once real registration numbers exist to compare
  against — there's nothing to compare against yet in a concept build.
- **Native-speaker review of the translations below** — see the caveat
  in that section. They're real, working translations, not placeholders,
  but they haven't been checked by a fluent reviewer.

## Offline-tolerant voting (built)

The frontend is now a small installable PWA (`manifest.json` + `sw.js`):
the app shell — markup, styles, script, the language dictionary, the
emblem — is cached on first load and still opens with no connection.
`sw.js` deliberately never caches anything under `/api/`, so this never
risks serving stale or sensitive data; it only makes the empty shell load
offline.

Voting itself is queue-and-retry: if a ballot submission fails because the
device has no connection (not because the server rejected it — `api()` in
`app.js` distinguishes the two), the ballot is held in `localStorage` and
retried automatically on the browser's `online` event, on next app load,
or via a manual "Retry now" button on a persistent offline banner.

**The honest trade-off:** this means an unsent ballot's candidate choice
sits briefly in the browser's local storage on that device, rather than
existing nowhere until it reaches the server. That's a real, deliberate
cost, not an oversight — it's what makes "don't lose a citizen's vote to
a dropped connection on a bad rural signal" possible at all. Mitigations
worth layering on for a production build: clear the entry the instant it
syncs (already done here), warn voters clearly on shared/public devices,
and consider encrypting the queued payload at rest with a key the device
never persists.

## Multilingual UI (built, translations are draft)

Every static UI string now runs through `i18n.js` via `data-i18n`
attributes and `applyLanguage()` in `app.js` — English, Hausa, Yorùbá,
Igbo, and Nigerian Pidgin are all real, working translations you can
switch between live (language picker on the login screen and in the
masthead), not a stub language list. Anything missing in a language
falls back to English automatically.

**Caveat, stated plainly:** these translations were produced without a
native-speaker review pass. I'm reasonably confident in the everyday
vocabulary; civic/legal terms (activation, jurisdiction, step-up
verification, and so on) are exactly the kind of thing a machine-assisted
translation can get subtly wrong, and Pidgin in particular is easy to get
the *tone* wrong on even when the words are right. A visible banner
("Draft translation — pending review by a native speaker") shows
automatically whenever a non-English language is selected, precisely so
this isn't quietly presented as finished. Get each language reviewed by a
fluent speaker before using this with real voters.

## Public ledger CSV export (built)

The Transparency page and the no-login public results view both have a
"Download ledger (CSV)" button — the same anonymous, hash-chained ledger
`GET /api/public/ledger` returns, exported client-side for anyone who
wants to run their own analysis outside the app (a journalist, a party
agent, a researcher).

## Still open

This is a visual and structural pass, not a full accessibility or
usability audit. Before treating this as competition-final: run it past a
few outside reviewers, check colour contrast against WCAG AA at every
text size used, and test the mobile layout on an actual device rather
than a resized browser window.
